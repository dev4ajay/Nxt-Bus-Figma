import React from 'react'
import Header from '../components/Layouts/Header'
import HomeBanner from '../components/HomeSections/HomeBanner'

function Home() {
  return (
    <React.Fragment>
        
        {/* <div  class="d-flex align-items-center"> */}
          <HomeBanner/>
            
        {/* </div> */}
    </React.Fragment>
  )
}

export default Home